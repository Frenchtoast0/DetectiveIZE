package com.IsaacW.OOPcredit;

import java.util.ArrayList;

public class Room {

    private int counter; //counter for controlling text size

    public String name; //name of room
    private String description; //description of room
    private ArrayList<Thing> things = new ArrayList<Thing>(); //thing list of objects in room
    private ArrayList<String> stringParallel = new ArrayList<String>(); //parallel array of strings to look-up object easily

    /**
     * Initializes a room object
     *
     * @param name - name of room
     * @param description - room description
     */
    public Room(String name, String description){
        this.name = name;
        this.description = description;

    }

    /**
     * Overloaded room constructor.  Assigns description and name to default values.
     */
    public Room()
    {
        this.name = "Default name";
        this.description = "Default Description";
    }

    /**
     * Returns the name of the room
     *
     * @return - room name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Prints out a description of the room, formatted
     */
    public void readDescription()
    {
        counter = 0;
        System.out.print("\n");
        for (int i = 0; i < description.length(); i++)
        {
            System.out.print(description.charAt(i));
            counter++;

            if (counter > 70 && description.charAt(i) == ' ')
            {
                System.out.print("\n");
                counter = 0;
            }
        }
        System.out.print("\n");
    }

    /**
     * Tells a thing object to print its description if it exists in the current room
     *
     * @param objectName - name of the thing
     */
    public void examine(String objectName)
    {
        int i = stringParallel.indexOf(objectName);
        if (i >= 0)
        {
            things.get(i).readDescription();
        }
        else
        {
            System.out.println("\nItem does not exist in this room.");
        }

    }

    /**
     * Initializes things in the room
     *
     * @param name - name of thing
     * @param description - description of thing
     */
    public void addThing(String name, String description) {
        things.add(new Thing(name, description));
        stringParallel.add(name);
    }
}
