package com.IsaacW.OOPcredit;

import java.util.Scanner;

public class Main {

    private static Scanner s = new Scanner(System.in); //gets input
    private static Map m = new Map(); //controls player movement

    private static String accused = ""; //accused suspect
    private static int counter = 0; //used for controlling size of text lines

    /**
     * Controls game flow
     *
     * @param args - not needed
     * @throws InterruptedException - keeps Thread.sleep() from crashing the program
     */
    public static void main(String[] args) throws InterruptedException{

        intro();
        s.nextLine();

        instructions();
        s.nextLine();

        String action;
        m.getCurrentRoom().readDescription();

        while (accused.equals(""))
        {
            action = ask();

            act(action);

            Thread.sleep(1000);
        }

        ending(accused);
    }

    /**
     * Introduces the storyline
     *
     * @throws InterruptedException - keeps Thread.sleep() from crashing program
     */
    private static void intro() throws InterruptedException
    {
        System.out.println("Game starting");

        for (int i = 0; i < 12; i ++)
        {
            System.out.print(".");
            Thread.sleep(500);
        }

        p("\nYou, Detective IZE, have just arrived at Bayport Apartments to investigate an apartment with police Sergeant Riley. ");
        p("The person who lives in the apartment has been stealing ketchup packets from major fast food places. ");
        p("He/She, however, hasn't been back for days since police took up the case and the room owner isn't on file. ");
        p("The Sergeant has a list of three suspected people which you can ask for information on. ");
        p("It is up to you to determine the guilty one and bring his/her ketchup stealing crimes to justice!");

        counter = 0;
    }

    /**
     * Prints out the instructions
     */
    private static void instructions()
    {
        System.out.println("\n*************************\n");
        System.out.println("You will move about the game inputting commands.\n");
        System.out.println("Commands:");
        System.out.println("goto [room name or \"police\"] - move to the specified place");
        System.out.println("examine [object] - learn about the specified object");
        System.out.println("accuse [suspect full name] - accuse a suspect, must be with Sgt. Riley");
        System.out.println("help - displays these instructions again");
        System.out.println("\n*************************");
    }

    /**
     * Runs appropriate action after a suspect has been chosen
     *
     * @param accused - name of suspect
     */
    private static void ending(String accused)
    {
        if (accused.equals("sam yacho") || accused.equals("sam") || accused.equals("mr. yacho") || accused.equals("suspect2") || accused.equals("2"))
        {
            answer();
        }
        else if (accused.equals("isaac wittmeier"))
        {
            System.out.println("\nVery clever--but no, the creator of this game is not the guilty party.  You lose! ");
        }
        else
        {
            p("\nYou accused the wrong person.  The guilty party has escaped to steal more ketchup and you have lost the game.");
        }
    }

    /**
     * Gets the player's action
     *
     * @return - player's input, lowercase
     */
    private static String ask(){
        System.out.print("\nAction: ");
        return s.nextLine().toLowerCase();
    }

    /**
     * Responds to the player's inputted command
     *
     * @param action - inputted action from player
     * @throws InterruptedException - keeps Thread.sleep() from crashing program
     */
    private static void act(String action) throws InterruptedException
    {
        if (action.startsWith("goto"))
        {
            String nextRoom = action.substring(5); //room to go to
            m.switchRoom(nextRoom);
        }
        else if (action.startsWith("examine "))
        {
            String object = action.substring(8); //object to examine
            System.out.println("\nExamining " + object + "...");

            Thread.sleep(1000);

            m.getCurrentRoom().examine(object);
        }
        else if (action.startsWith("accuse "))
        {
            if (m.getCurrentRoom().getName().equals("police"))
            {
                accused = action.substring(7);
            }
            else
            {
                System.out.println("\nSgt. Riley is too far away to hear your accusation.");
            }
        }
        else if (action.startsWith("suspects"))
        {
            if (m.getCurrentRoom().getName().equals("lobby"))
            {
                m.getCurrentRoom().examine("police");
            }
        }
        else if (action.equals("help"))
        {
            instructions();
        }
        else
        {
            System.out.println("\nInvalid action.");
        }
    }

    /**
     * Formats text to print to screen
     *
     * @param text - text string
     */
    private static void p(String text)
    {
        for (int i = 0; i < text.length(); i++)
        {
            System.out.print(text.charAt(i));
            counter++;

            if (counter > 70 && text.charAt(i) == ' ')
            {
                System.out.print("\n");
                counter = 0;
            }
        }
    }

    /**
     * Storyline if player wins
     */
    private static void answer()
    {
        p("\nYou win the game!  Sam Yacho was the guilty one.  He loved to eat ketchup and hoped to run fast-food places out of business. ");
        p("The black hair was not a human's but his tuxedo cat.  Gerald Smock was allergic to ketchup so he couldn't have been the one. ");
        p("The turtle t-shirt was only circumstantial--any of the three could have owned it.  The lettuce just fell into the bathtub when Sam was trying to wash it. ");
        p("Louise was not the guilty one since she is a house cleaner (very clean standards).  Her bed would have been made and ketchup would not be on the light switch in the bathroom. ");
        p("Finally, the medicated band aids may have seemed ambiguous, however, they were used for cat scratches.");
        System.out.println("\n\nCongratulations! Detective IZE has done it again and brought another criminal to justice!");
    }
}
