package com.IsaacW.OOPcredit;

public class Thing {

    private String description; //description of room
    public String name; //name of room

    /**
     * Constructor for a thing
     *
     * @param name - name of thing
     * @param description - description of thing
     */
    public Thing(String name, String description){
        this.name = name;
        this.description = description;
    }

    /**
     * Prints out the thing's description
     */
    public void readDescription(){
        System.out.println("\n" + description);
    }
}
