package com.IsaacW.OOPcredit;

public class Map {

    private Room currentRoom; //room the player is in

    //Following room objects are placeholders for the game rooms to be initialized in
    private Room lobby;
    private Room police;

    private Room apartment;
    private Room kitchen;
    private Room bathroom;
    private Room bedroom;

    /**
     * Initializes all the game rooms with their descriptions
     */
    public Map()
    {
        lobby = new Room("lobby", "You are in the elegant wood and marble lobby of Bayport Apartments.  From here, you can take the elevator to the \"apartment\" or talk to Sgt. Riley.");
        police = new Room("police", "Sgt. Riley: \"Hello Detective IZE! How can I help you? (you can examine \"suspect1\", \"suspect2\", or \"suspect3\"\").");

        apartment = new Room("apartment", "You are in the dirty living room of the apartment of the suspect.  There are ketchup packets all over the floor.  It has doors leading to the \"kitchen\", the \"bathroom\", or the \"bedroom\".");
        kitchen = new Room("kitchen", "You are in the dusty kitchen of the apartment.  There is little furniture, but you think clues may be found in the \"fridge\" or on the \"counter\".");
        bathroom = new Room("bathroom", "You are in the bathroom. Ketchup is smeared on the light switch. Clues may be found in the \"cabinet\" or maybe the \"bathtub\".");
        bedroom = new Room("bedroom", "You are in the bedroom.  There is an unmade \"bed\" and an old \"dresser\".");

        lobby.addThing("police", "You can talk to Sgt. Riley by \"going to\" him.");

        police.addThing("suspect1", "Gerald Smock: male, black hair, allergic to tomatoes, owns a lettuce-loving turtle, works at Central Bank.");
        police.addThing("suspect2", "Sam Yacho: male, blond hair, has trouble sleeping, owns a tuxedo cat, works as a doctor.");
        police.addThing("suspect3", "Louise Tripple: female, black hair, cousin to Sam Yacho, owns an orange cat, works as a housekeeper.");

        kitchen.addThing("fridge", "The fridge has a few eggs in a carton and several ketchup packets.  There is also a cooled, chamomile, tea.");
        kitchen.addThing("counter", "A receipt is sitting on the counter: 2L milk, tuna, lettuce, salad dressing.");
        kitchen.addThing("stove", "You open the stove to find the credits: created by Isaac Wittmeier, 2019");

        bathroom.addThing("cabinet", "Inside the cabinet is a package of medicated band aids.");
        bathroom.addThing("bathtub", "There is lettuce in the bathtub, strange...");

        bedroom.addThing("bed", "Under the pillow you find some black hair.");
        bedroom.addThing("dresser", "Inside the dresser you find a t-shirt from Turtle World.");

        currentRoom = lobby;
    }

    /**
     * Switches the room of the player
     *
     * @param room - string input from player of room name
     */
    public void switchRoom(String room)
    {
        if (room.equals("lobby"))
        {
            currentRoom = lobby;
        }
        else if (room.equals("apartment"))
        {
            currentRoom = apartment;
        }
        else if (room.equals("kitchen"))
        {
            currentRoom = kitchen;
        }
        else if (room.equals("bathroom"))
        {
            currentRoom = bathroom;
        }
        else if (room.equals("bedroom"))
        {
            currentRoom = bedroom;
        }
        else if (room.equals("police") || room.equals("riley"))
        {
            currentRoom = police;
        }
        else
        {
            System.out.println("\nInvalid destination");
        }

        currentRoom.readDescription();
    }

    /**
     * Returns what room the player is in
     *
     * @return - the room object the player is in
     */
    public Room getCurrentRoom()
    {
        return currentRoom;
    }

    /**
     * Returns the name of the room the player is in
     *
     * @return - string name of room
     */
    public String getCurrentRoomName()
    {
        return currentRoom.getName();
    }
}
